/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/EmptyTestNGTest.java to edit this template
 */
package com.mycompany.part3s;

import static org.testng.Assert.*;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

/**
 *
 * @author lab_services_student
 */
public class PART3SNGTest {
    
    public PART3SNGTest() {
    }

    @BeforeClass
    public static void setUpClass() throws Exception {
    }

    @AfterClass
    public static void tearDownClass() throws Exception {
    }

    @BeforeMethod
    public void setUpMethod() throws Exception {
    }

    @AfterMethod
    public void tearDownMethod() throws Exception {
    }

    /**
     * Test of start method, of class PART3S.
     */
    @Test
    public void testStart() {
        System.out.println("start");
        PART3S instance = new PART3S();
        instance.start();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of searchTaskByName method, of class PART3S.
     */
    @Test
    public void testSearchTaskByName() {
        System.out.println("searchTaskByName");
        PART3S instance = new PART3S();
        instance.searchTaskByName();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of searchTasksByDeveloper method, of class PART3S.
     */
    @Test
    public void testSearchTasksByDeveloper() {
        System.out.println("searchTasksByDeveloper");
        PART3S instance = new PART3S();
        instance.searchTasksByDeveloper();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of deleteTask method, of class PART3S.
     */
    @Test
    public void testDeleteTask() {
        System.out.println("deleteTask");
        PART3S instance = new PART3S();
        instance.deleteTask();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of updateTaskStatus method, of class PART3S.
     */
    @Test
    public void testUpdateTaskStatus() {
        System.out.println("updateTaskStatus");
        PART3S instance = new PART3S();
        instance.updateTaskStatus();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of updateTaskDuration method, of class PART3S.
     */
    @Test
    public void testUpdateTaskDuration() {
        System.out.println("updateTaskDuration");
        PART3S instance = new PART3S();
        instance.updateTaskDuration();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of addTask method, of class PART3S.
     */
    @Test
    public void testAddTask() {
        System.out.println("addTask");
        PART3S instance = new PART3S();
        instance.addTask();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of showReport method, of class PART3S.
     */
    @Test
    public void testShowReport() {
        System.out.println("showReport");
        PART3S instance = new PART3S();
        instance.showReport();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of showCompletedTasks method, of class PART3S.
     */
    @Test
    public void testShowCompletedTasks() {
        System.out.println("showCompletedTasks");
        PART3S instance = new PART3S();
        instance.showCompletedTasks();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of showTaskWithLongestDuration method, of class PART3S.
     */
    @Test
    public void testShowTaskWithLongestDuration() {
        System.out.println("showTaskWithLongestDuration");
        PART3S instance = new PART3S();
        instance.showTaskWithLongestDuration();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of main method, of class PART3S.
     */
    @Test
    public void testMain() {
        System.out.println("main");
        String[] args = null;
        PART3S.main(args);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    
}

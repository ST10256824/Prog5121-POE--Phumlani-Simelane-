/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.part3s;
import javax.swing.UIManager;
import java.awt.Color;
import javax.swing.JOptionPane;


public class PART3S {
    //PARALLEL ARRAYS
    private String[] taskNames;
    private String[] taskIds;
    private String[] taskNumbers;
    private String[] taskDescriptions;
    private String[] developersDetails;
    private String[] taskStatuses;
    private int[] taskDurations;
    private int totalHours = 0;
    private int taskCount = 0;

    public PART3S() {
        int initialCapacity = 10;
        taskNames = new String[initialCapacity];
        taskIds = new String[initialCapacity];
        taskNumbers = new String[initialCapacity];
        taskDescriptions = new String[initialCapacity];
        developersDetails = new String[initialCapacity];
        taskStatuses = new String[initialCapacity];
        taskDurations = new int[initialCapacity];
    }
   public void start() {
       UIManager.put("OptionPane.background", new Color(216, 191, 216));
    while (true) {
        String command = (String) JOptionPane.showInputDialog(
            null,
            "Choose an option:\n",
            "Options",
            JOptionPane.PLAIN_MESSAGE,
            null,
            new String[] {
                "Add Task",
                "Show Report",
                "Show Completed Tasks",
                "Task with Longest Duration",
                "Search Task by Name",
                "Search Tasks by Developer",
                "Delete Task",
                "Quit",
                "Update Task Status",
                "Update Task Duration"
            },
            "Add Task"
        );

        if (command != null) {
            if (command.equals("Add Task")) {
                addTask();
            } else if (command.equals("Show Report")) {
                showReport();
            } else if (command.equals("Show Completed Tasks")) {
                showCompletedTasks();
            } else if (command.equals("Task with Longest Duration")) {
                showTaskWithLongestDuration();
            } else if (command.equals("Search Task by Name")) {
                searchTaskByName();
            } else if (command.equals("Search Tasks by Developer")) {
                searchTasksByDeveloper();
            } else if (command.equals("Delete Task")) {
                deleteTask();
            } else if (command.equals("Quit")) {
                // Exit the program or perform cleanup
                break; // Exit the loop to end the program
            } else if (command.equals("Update Task Status")) {
                updateTaskStatus();
            } else if (command.equals("Update Task Duration")) {
                updateTaskDuration();
            }
        }
    }
}
public void searchTaskByName() {
    try {
        String searchName = JOptionPane.showInputDialog(null, "Please enter the task name to search: ");
        boolean found = false;

            StringBuilder searchResultBuilder = new StringBuilder();
            searchResultBuilder.append("Search Results:\n");

            for (int i = 0; i < taskCount; i++) {
                if (taskNames[i].equalsIgnoreCase(searchName)) {
                    searchResultBuilder.append("Task Name: ").append(taskNames[i]).append("\n");
                    searchResultBuilder.append("Task ID: ").append(taskIds[i]).append("\n");
                    searchResultBuilder.append("Task Number: ").append(taskNumbers[i]).append("\n");
                    searchResultBuilder.append("Task Description: ").append(taskDescriptions[i]).append("\n");
                    searchResultBuilder.append("Developer Details: ").append(developersDetails[i]).append("\n");
                    searchResultBuilder.append("Task Duration: ").append(taskDurations[i]).append(" hours\n\n");

                    found = true;
                }
            }

            if (found) {
                JOptionPane.showMessageDialog(null, searchResultBuilder.toString());
            } else
{
JOptionPane.showMessageDialog(null, "No tasks found with the given name.", "Search Results",
JOptionPane.INFORMATION_MESSAGE);
}
} catch (Exception e) {
JOptionPane.showMessageDialog(null, "An error occurred: " + e.getMessage(), "Error",
JOptionPane.ERROR_MESSAGE);
}
}

public void searchTasksByDeveloper() {
    try {
        String searchDeveloper = JOptionPane.showInputDialog(null, "Please enter the developer details to search: ");
        boolean found = false;

        StringBuilder searchResultBuilder = new StringBuilder();
        searchResultBuilder.append("Search Results:\n");

        for (int i = 0; i < taskCount; i++) {
            if (developersDetails[i].equalsIgnoreCase(searchDeveloper)) {
                searchResultBuilder.append("Task Name: ").append(taskNames[i]).append("\n");
                searchResultBuilder.append("Task ID: ").append(taskIds[i]).append("\n");
                searchResultBuilder.append("Task Number: ").append(taskNumbers[i]).append("\n");
                searchResultBuilder.append("Task Description: ").append(taskDescriptions[i]).append("\n");
                searchResultBuilder.append("Developer Details: ").append(developersDetails[i]).append("\n");
                searchResultBuilder.append("Task Duration: ").append(taskDurations[i]).append(" hours\n\n");

                found = true;
            }
        }

        if (found) {
            JOptionPane.showMessageDialog(null, searchResultBuilder.toString());
        } else {
            JOptionPane.showMessageDialog(null, "No tasks found for the given developer.", "Search Results",
                    JOptionPane.INFORMATION_MESSAGE);
        }
    } catch (Exception e) {
        JOptionPane.showMessageDialog(null, "An error occurred: " + e.getMessage(), "Error",
                JOptionPane.ERROR_MESSAGE);
    }
}

public void deleteTask() {
    try {
        String deleteId = JOptionPane.showInputDialog(null, "Please enter the task ID to delete: ");
        boolean deleted = false;

        for (int i = 0; i < taskCount; i++) {
            if (taskIds[i].equals(deleteId)) {
                // Move the last task to the deleted task's position
                taskNames[i] = taskNames[taskCount - 1];
                taskIds[i] = taskIds[taskCount - 1];
                taskNumbers[i] = taskNumbers[taskCount - 1];
                taskDescriptions[i] = taskDescriptions[taskCount - 1];
                developersDetails[i] = developersDetails[taskCount - 1];
                taskStatuses[i] = taskStatuses[taskCount - 1];
                taskDurations[i] = taskDurations[taskCount - 1];

                // Set the last task's position to null or default values
                taskNames[taskCount - 1] = null;
                taskIds[taskCount - 1] = null;
                taskNumbers[taskCount - 1] = null;
                taskDescriptions[taskCount - 1] = null;
                developersDetails[taskCount - 1] = null;
                taskStatuses[taskCount - 1] = null;
                taskDurations[taskCount - 1] = 0;

                taskCount--;
                deleted = true;
                JOptionPane.showMessageDialog(null, "Task deleted successfully.", "Success",
                        JOptionPane.INFORMATION_MESSAGE);
                break;
            }
        }

        if (!deleted) {
            JOptionPane.showMessageDialog(null, "No task found with the given ID.", "Error",
                    JOptionPane.ERROR_MESSAGE);
        }
    } catch (Exception e) {
        JOptionPane.showMessageDialog(null, "An error occurred: " + e.getMessage(), "Error",
                JOptionPane.ERROR_MESSAGE);
    }
}

public void updateTaskStatus() {
    try {
        String updateId = JOptionPane.showInputDialog(null, "Please enter the task ID to update status: ");
        boolean updated = false;

        for (int i = 0; i < taskCount; i++) {
            if (taskIds[i].equals(updateId)) {
                String newStatus = JOptionPane.showInputDialog(null, "Please enter the new status for the task: ");
                taskStatuses[i] = newStatus;
                updated = true;
                JOptionPane.showMessageDialog(null, "Task status updated successfully.", "Success",
                        JOptionPane.INFORMATION_MESSAGE);
                break;
            }
        }

        if (!updated) {
            JOptionPane.showMessageDialog(null, "No task found with the given ID.", "Error",
                    JOptionPane.ERROR_MESSAGE);
        }
    } catch (Exception e) {
        JOptionPane.showMessageDialog(null, "An error occurred: " + e.getMessage(), "Error",
                JOptionPane.ERROR_MESSAGE);
    }
}

public void updateTaskDuration() {
    try {
        String updateId = JOptionPane.showInputDialog(null, "Please enter the task ID to update duration: ");
        boolean updated = false;

        for (int i = 0; i < taskCount; i++) {
            if (taskIds[i].equals(updateId)) {
                String newDuration = JOptionPane.showInputDialog(null, "Please enter the new duration for the task (in hours): ");
                int duration = Integer.parseInt(newDuration);
                taskDurations[i] = duration;
                totalHours += duration;
                updated = true;
                JOptionPane.showMessageDialog(null, "Task duration updated successfully.", "Success",
                        JOptionPane.INFORMATION_MESSAGE);
                break;
            }
        }

        if (!updated) {
            JOptionPane.showMessageDialog(null, "No task found with the given ID.", "Error",
                    JOptionPane.ERROR_MESSAGE);
        }
    } catch (NumberFormatException e) {
        JOptionPane.showMessageDialog(null, "Invalid duration. Please enter a valid number.", "Error",
                JOptionPane.ERROR_MESSAGE);
    } catch (Exception e) {
        JOptionPane.showMessageDialog(null, "An error occurred: " + e.getMessage(), "Error",
                JOptionPane.ERROR_MESSAGE);
    }
}

public void addTask() {
    try {
        if (taskCount == taskNames.length) {
            // Increase the array size by 10 if it is full
            increaseArraySize();
        }

        String taskName = JOptionPane.showInputDialog(null, "Enter the task name: ");
        String taskId = JOptionPane.showInputDialog(null, "Enter the task ID: ");
        String taskNumber = JOptionPane.showInputDialog(null, "Enter the task number: ");
        String taskDescription = JOptionPane.showInputDialog(null, "Enter the task description: ");
        String developerDetails = JOptionPane.showInputDialog(null, "Enter the developer details: ");
        String taskStatus = JOptionPane.showInputDialog(null, "Enter the task status: ");
        String taskDurationInput = JOptionPane.showInputDialog(null, "Enter the task duration (in hours): ");
        int taskDuration = Integer.parseInt(taskDurationInput);
        totalHours += taskDuration;

        taskNames[taskCount] = taskName;
        taskIds[taskCount] = taskId;
        taskNumbers[taskCount] = taskNumber;
        taskDescriptions[taskCount] = taskDescription;
        developersDetails[taskCount] = developerDetails;
        taskStatuses[taskCount] = taskStatus;
        taskDurations[taskCount] = taskDuration;

        taskCount++;

        JOptionPane.showMessageDialog(null, "Task added successfully.", "Success",
                JOptionPane.INFORMATION_MESSAGE);
    } catch (NumberFormatException e) {
        JOptionPane.showMessageDialog(null, "Invalid duration. Please enter a valid number.", "Error",
                JOptionPane.ERROR_MESSAGE);
    } catch (Exception e) {
        JOptionPane.showMessageDialog(null, "An error occurred: " + e.getMessage(), "Error",
                JOptionPane.ERROR_MESSAGE);
    }
}

public void showReport() {
    try {
        StringBuilder reportBuilder = new StringBuilder();
        reportBuilder.append("Task Report:\n\n");

        for (int i = 0; i < taskCount; i++) {
            reportBuilder.append("Task Name: ").append(taskNames[i]).append("\n");
            reportBuilder.append("Task ID: ").append(taskIds[i]).append("\n");
            reportBuilder.append("Task Number: ").append(taskNumbers[i]).append("\n");
            reportBuilder.append("Task Description: ").append(taskDescriptions[i]).append("\n");
            reportBuilder.append("Developer Details: ").append(developersDetails[i]).append("\n");
            reportBuilder.append("Task Status: ").append(taskStatuses[i]).append("\n");
            reportBuilder.append("Task Duration: ").append(taskDurations[i]).append(" hours\n\n");
        }

        reportBuilder.append("Total Task Count: ").append(taskCount).append("\n");
        reportBuilder.append("Total Hours: ").append(totalHours);

        JOptionPane.showMessageDialog(null, reportBuilder.toString(), "Task Report",
                JOptionPane.INFORMATION_MESSAGE);
    } catch (Exception e) {
        JOptionPane.showMessageDialog(null, "An error occurred: " + e.getMessage(), "Error",
                JOptionPane.ERROR_MESSAGE);
    }
}

public void showCompletedTasks() {
    try {
        StringBuilder completedTasksBuilder = new StringBuilder();
        completedTasksBuilder.append("Completed Tasks:\n\n");

        for (int i = 0; i < taskCount; i++) {
            if (taskStatuses[i].equalsIgnoreCase("completed")) {
                completedTasksBuilder.append("Task Name: ").append(taskNames[i]).append("\n");
                completedTasksBuilder.append("Task ID: ").append(taskIds[i]).append("\n");
                completedTasksBuilder.append("Task Number: ").append(taskNumbers[i]).append("\n");
                completedTasksBuilder.append("Task Description: ").append(taskDescriptions[i]).append("\n");
                completedTasksBuilder.append("Developer Details: ").append(developersDetails[i]).append("\n");
                completedTasksBuilder.append("Task Duration: ").append(taskDurations[i]).append(" hours\n\n");
            }
        }

        JOptionPane.showMessageDialog(null, completedTasksBuilder.toString(), "Completed Tasks",
                JOptionPane.INFORMATION_MESSAGE);
    } catch (Exception e) {
        JOptionPane.showMessageDialog(null, "An error occurred: " + e.getMessage(), "Error",
                JOptionPane.ERROR_MESSAGE);
    }
}

public void showTaskWithLongestDuration() {
    try {
        int maxDuration = -1;
        int maxDurationIndex = -1;

        for (int i = 0; i < taskCount; i++) {
            if (taskDurations[i] > maxDuration) {
                maxDuration = taskDurations[i];
                maxDurationIndex = i;
            }
        }

        if (maxDurationIndex != -1) {
            StringBuilder taskWithLongestDurationBuilder = new StringBuilder();
            taskWithLongestDurationBuilder.append("Task with Longest Duration:\n\n");
            taskWithLongestDurationBuilder.append("Task Name: ").append(taskNames[maxDurationIndex]).append("\n");
            taskWithLongestDurationBuilder.append("Task ID: ").append(taskIds[maxDurationIndex]).append("\n");
            taskWithLongestDurationBuilder.append("Task Number: ").append(taskNumbers[maxDurationIndex]).append("\n");
            taskWithLongestDurationBuilder.append("Task Description: ").append(taskDescriptions[maxDurationIndex]).append("\n");
            taskWithLongestDurationBuilder.append("Developer Details: ").append(developersDetails[maxDurationIndex]).append("\n");
            taskWithLongestDurationBuilder.append("Task Duration: ").append(taskDurations[maxDurationIndex]).append(" hours");

            JOptionPane.showMessageDialog(null, taskWithLongestDurationBuilder.toString(), "Task with Longest Duration",
                    JOptionPane.INFORMATION_MESSAGE);
        } else {
            JOptionPane.showMessageDialog(null, "No tasks found.", "Task with Longest Duration",
                    JOptionPane.INFORMATION_MESSAGE);
        }
    } catch (Exception e) {
        JOptionPane.showMessageDialog(null, "An error occurred: " + e.getMessage(), "Error",
                JOptionPane.ERROR_MESSAGE);
    }
}

private void increaseArraySize() {
    int newCapacity = taskNames.length + 10;

    String[] newTaskNames = new String[newCapacity];
    String[] newTaskIds = new String[newCapacity];
    String[] newTaskNumbers = new String[newCapacity];
    String[] newTaskDescriptions = new String[newCapacity];
    String[] newDevelopersDetails = new String[newCapacity];
    String[] newTaskStatuses = new String[newCapacity];
    int[] newTaskDurations = new int[newCapacity];

    System.arraycopy(taskNames, 0, newTaskNames, 0, taskCount);
    System.arraycopy(taskIds, 0, newTaskIds, 0, taskCount);
    System.arraycopy(taskNumbers, 0, newTaskNumbers, 0, taskCount);
    System.arraycopy(taskDescriptions, 0, newTaskDescriptions, 0, taskCount);
    System.arraycopy(developersDetails, 0, newDevelopersDetails, 0, taskCount);
    System.arraycopy(taskStatuses, 0, newTaskStatuses, 0, taskCount);
    System.arraycopy(taskDurations, 0, newTaskDurations, 0, taskCount);

    taskNames = newTaskNames;
    taskIds = newTaskIds;
    taskNumbers = newTaskNumbers;
    taskDescriptions = newTaskDescriptions;
    developersDetails = newDevelopersDetails;
    taskStatuses = newTaskStatuses;
    taskDurations = newTaskDurations;
}

public static void main(String[] args) {
    PART3S aGrade = new PART3S();
    aGrade.start();
}
}
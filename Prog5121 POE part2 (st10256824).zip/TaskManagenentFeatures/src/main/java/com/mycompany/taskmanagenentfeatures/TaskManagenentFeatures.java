/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */
import javax.swing.JOptionPane;
import java.util.ArrayList;
import java.util.List;


/**
 *
 * @author RC_Student_lab
 */
public class TaskManagenentFeatures {
  
    
    public class TaskManagement{

        private static Object tasks;

public static void main(String[] args){

TaskManagement.displayMenu();
}
public void showWelcomeMessage(){
    JOptionPane.showMessageDialog(null, "WELCOME TO EASYKANBAN.");
}


        // Display the menu
        private static void displayMenu() {
        while (true){
            String input = JOptionPane.showInputDialog(
            "Welcome to Task Management System\n" +
                    "1. Add Task\n" +
                    "2. Display Task\n" +
                    "3. Exit\n" +
                    "Please enter your choice:");
            
            int choice;
            try {
                choice = Integer.parseInt(input);
            } catch (NumberFormatException e){
                JOptionPane.showMessageDialog(null, "Invalid input, Please enter a number");
                continue;
                
           
            }
            switch (choice){
                case 1:
                    addTask();
                    break;
                case 2:
                    displayTask();
                    break;
                case 3:
                    JOptionPane.showMessageDialog(null, "Exiting the system");
                    return;
                default:
                    JOptionPane.showMessageDialog(null, "Invalid choice, Please enter a number");
            }
        }
        
        
        }
        // Add task
        private static void addTask() {
            String taskName = JOptionPane.showInputDialog("Enter task name:");
            String developerName = JOptionPane.showInputDialog("Enter developer name:");
            int taskDuration;
            try{
                taskDuration = Integer.parseInt(JOptionPane.showInputDialog("Enter task duration in hours:"));
                }catch (NumberFormatException e){
                    JOptionPane.showMessageDialog(null, "Invalid input, Please enter a number for task duration.");
                    return;
                    }
            
            String taskStatus = JOptionPane.showInputDialog("Enter task status:");
            
            if (taskName.length() >50){
                JOptionPane.showMessageDialog(null, "Task name should be less than 50 characters");
                return;
            }
            
            String taskID = generateTaskID(taskName, developerName);
            
            Task task = new Task(taskName, developerName, taskID, taskDuration, taskStatus);
            tasks.(task);
            
            JOptionPane.showMessageDialog(null, "Task added successfully.");
        }

        private static void displayTask() {
            StringBuilder taskReport = new StringBuilder("Task Report\n");
            for (Task task : tasks){
                taskReport.append(task.toString()).append("\n");
        }
        JOptionPane.showMessageDialog(null, taskReport.toString());
        }
        

        private static String generateTaskID(String taskName, String developerName) {
          return taskName.substring(0, 2).toUpperCase()+ developerName.substring(0, 2).toUpperCase() + (int) (Math.random() * 1000);
        }
        // Getter for tasks to facilitate unit testing
        public List<Task> getTasks(){
            return (List<Task>) tasks;
        }



    }













































}

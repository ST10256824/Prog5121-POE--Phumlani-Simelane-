/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
import javax.swing.JOptionPane;
import java.util.ArrayList;
import java.util.List;
/**
 *
 * @author RC_Student_lab
 */
class Task {
    
    private String taskName;
    private String developerName;
    private String taskID;
    private int taskDuration;
    private String taskStatus;
    
   public Task(String taskName, String developerName, String taskID, int taskDuration, String taskStatus) {
       this.taskName = taskName;
       this.developerName = developerName;
       this.taskID = taskID;
       this.taskDuration = taskDuration;
       this.taskStatus = taskStatus;
    }
   // Getters
   public String getTaskName(){
       return taskName;
   }
   public String getDeveloperName(){
       return developerName;
   }
   
   public int getTaskDuration(){
       return taskDuration;
   }
   
   public String getTaskStatus(){
       return taskStatus;
   } 
   
   public String toString(){
   return "Task ID: " + taskID + ", Task Name: " + taskName + ", Developer: " + developerName + ", Duration: " + taskDuration + " hours, Status: " + taskStatus;
   
   }

   public static void showMessage(){
       JOptionPane.showMessageDialog(null, "COMING SOON");
   }

   

    
    
}

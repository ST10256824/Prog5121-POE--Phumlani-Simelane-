/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import java.io.ByteArrayInputStream;
import java.io.BufferedInputStream;
import java.io.InputStream;
import java.util.List;

/**
 *
 * @author RC_Student_lab
 */
public class TaskManagementTest {

    private static TaskManagement taskManagement;
    
    private TaskManagementTest() {
    }
    
    @BeforeEach
    public static void setUp() {
        taskManagement = new TaskManagement();
    }
   
    
       
    

    // TODO add test methods here.
    // The methods must be annotated with annotation @Test. For example:
    //
    // @Test
    public void testAddTask(){
        String input = "Task1\nDeveloper1\5\nTo Do";
        InputStream in = new ByteArrayInputStream(input.getBytes());
        System.setIn(in);
        
        taskManagement.addTask();
        List<Task> tasks = taskManagement.getTask();
        assertEquals(1, tasks.size());
        assertEquals("Task1", tasks.get(0).getTaskName());
    }
    public void testNameTooLong(){
        taskManagement.addTask("ThisTaskNameIsMoreThan50CharactersLongSoItShouldFail", "Developer1", 5, "To Do");
        List<Task> tasks = taskManagement.getTasks();
        assertEquals(0, tasks.size());
    }
   public void testGenerarateTaskID(){
       String taskID = taskManagement.generateTaskID("Task1", "Developer1");
       assertNotNull(taskID);
       assertTrue(taskID.length() >=4); 
       
   }
   public void testDisplayTasks(){
        taskManagement.addTask("Task1", "Developer1", 5, "To Do");
        taskManagement.addTask("Task2", "Developer2", 3, "In Progress");

        String expectedOutput = "Task Report:\n" +
                "Task ID: TADE123, Task Name: Task1, Developer: Developer1, Duration: 5 hours, Status: To Do\n" +
                "Task ID: TADE456, Task Name: Task2, Developer: Developer2, Duration: 3 hours, Status: In Progress\n";

        assertEquals(expectedOutput, taskManagement.displayTasks());
   }
   

    private static class TaskManagement {

        public TaskManagement() {
        }

        private void addTask() {
            throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
        }

        private List<Task> getTask() {
            throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
        }

        private String generateTaskID(String task1, String developer1) {
            throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
        }

        private void addTask(String thisTaskNameIsMoreThan50CharactersLongSoI, String developer1, int i, String to_Do) {
            throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
        }

        private List<Task> getTasks() {
            throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
        }

        private Object displayTasks() {
            throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
        }
    }
}
